import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv('logs.csv', names=['timestamp', 'action', 'dare_id', 'mood', 'streak'])
df['timestamp'] = pd.to_datetime(df['timestamp'])

print("\nTotal Actions:", len(df))
print(df['action'].value_counts())
print("\nMost Common Moods:")
print(df['mood'].value_counts())

plt.figure(figsize=(8, 5))
sns.countplot(data=df, x='mood', hue='action')
plt.title('Mood vs Accept/Skip Count')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

plt.figure(figsize=(6, 4))
sns.histplot(df['streak'], kde=True)
plt.title('Distribution of Streaks')
plt.xlabel('Streak')
plt.show()

df.set_index('timestamp').resample('D').size().plot(title='Activity Per Day', marker='o')
plt.ylabel('Total Actions')
plt.show()
