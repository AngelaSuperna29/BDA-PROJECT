import csv
from datetime import datetime

def log_user_action(action, dare_id, mood, streak):
    with open("logs.csv", mode="a", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([datetime.now(), action, dare_id, mood, streak])
